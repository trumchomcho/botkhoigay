module.exports = {
  Death: require('./Death.type'),
  Movement: require('./Movement.type')
};
