module.exports = class Ability {
  // overide
  static question(player) {}

  // overide
  static check(player, value) {}

  // overide
  static async nightend(player, value, listDeaths) {}
};
